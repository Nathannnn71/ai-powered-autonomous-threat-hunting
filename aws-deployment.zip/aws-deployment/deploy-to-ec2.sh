#!/bin/bash
# Deploy AI Threat Dashboard to EC2
# Account: 714377355924
# Region: us-east-1

echo "🚀 Deploying AI Threat Dashboard to EC2..."

# Build the React application
echo "📦 Building React application..."
npm run build

# Create deployment package
echo "📁 Creating deployment package..."
tar -czf dashboard-deploy.tar.gz dist/ package.json

# Upload to S3 bucket (temporary storage)
echo "☁️ Uploading to S3..."
aws s3 cp dashboard-deploy.tar.gz s3://ai-powered-autonomous-threat-hunting-website/deployment/

# EC2 deployment commands (run these on your EC2 instance)
cat << 'EOF' > ec2-setup.sh
#!/bin/bash
# Run this script on your EC2 instance

# Install Node.js and PM2
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo npm install -g pm2

# Download deployment package
aws s3 cp s3://ai-powered-autonomous-threat-hunting-website/deployment/dashboard-deploy.tar.gz .
tar -xzf dashboard-deploy.tar.gz

# Install dependencies and start application
cd dist
npm install --production
pm2 start ecosystem.config.js
pm2 startup
pm2 save

echo "✅ Dashboard deployed and running on EC2!"
EOF

echo "✅ Deployment package ready!"
echo "📋 Next: Run ec2-setup.sh on your EC2 instance"