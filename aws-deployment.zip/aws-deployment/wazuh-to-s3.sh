#!/bin/bash
# Wazuh to S3 Integration Script
# This script processes Wazuh logs and uploads them to S3

WAZUH_LOG_PATH="/var/ossec/logs/alerts/alerts.json"
S3_BUCKET_RAW="wazuh-raw"
S3_BUCKET_RESULTS="wazuh-results"
TEMP_DIR="/tmp/wazuh-processing"

echo "🔍 Starting Wazuh log processing..."

# Create temporary directory
mkdir -p $TEMP_DIR

# Function to process logs and create analysis
process_logs() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local raw_file="$TEMP_DIR/raw_alerts_$timestamp.json"
    local analysis_file="$TEMP_DIR/analysis_$timestamp.json"
    
    # Copy recent logs (last 1000 lines)
    tail -n 1000 $WAZUH_LOG_PATH > $raw_file
    
    # Create analysis (Python script would be better, but using basic shell for now)
    cat > $analysis_file << EOF
{
  "summary": {
    "summary": "Wazuh threat analysis for $(date)",
    "common_patterns": ["Failed login attempts", "Suspicious network activity", "File integrity monitoring"],
    "key_findings": ["$(grep -c 'level.*[0-9][0-9]' $raw_file) high-priority alerts detected"],
    "total_logs": $(wc -l < $raw_file),
    "normal_logs": $(grep -c 'level.*[0-5]' $raw_file || echo 0),
    "abnormal_logs": $(grep -c 'level.*[6-9]' $raw_file || echo 0)
  },
  "logs": [
$(tail -n 10 $raw_file | sed 's/$/,/' | sed '$ s/,$//')
  ],
  "metrics": [
    {"time": "$(date +%H:00)", "anomalies": $(grep -c 'level.*[6-9]' $raw_file || echo 0), "logs": $(wc -l < $raw_file)}
  ],
  "timestamp": "$(date -Iseconds)"
}
EOF
    
    # Upload to S3
    echo "☁️ Uploading to S3..."
    aws s3 cp $raw_file s3://$S3_BUCKET_RAW/$(date +%Y/%m/%d)/
    aws s3 cp $analysis_file s3://$S3_BUCKET_RESULTS/
    
    # Update latest analysis
    aws s3 cp $analysis_file s3://$S3_BUCKET_RESULTS/latest_analysis.json
    
    echo "✅ Processing complete for timestamp: $timestamp"
}

# Run processing
if [ -f "$WAZUH_LOG_PATH" ]; then
    process_logs
else
    echo "❌ Wazuh log file not found: $WAZUH_LOG_PATH"
    echo "📝 Creating sample data for testing..."
    
    # Create sample data for testing
    cat > $TEMP_DIR/sample_analysis.json << EOF
{
  "summary": {
    "summary": "Sample threat analysis - Wazuh integration pending",
    "common_patterns": ["Sample pattern 1", "Sample pattern 2"],
    "key_findings": ["System setup in progress"],
    "total_logs": 42,
    "normal_logs": 38,
    "abnormal_logs": 4
  },
  "logs": [
    {"log_id": "sample_001", "category": "normal", "hypotheses": ["Normal system activity"], "investigation_log": "Sample log entry"},
    {"log_id": "sample_002", "category": "abnormal", "hypotheses": ["Potential threat detected"], "investigation_log": "Sample threat log"}
  ],
  "metrics": [
    {"time": "$(date +%H:00)", "anomalies": 4, "logs": 42}
  ],
  "timestamp": "$(date -Iseconds)"
}
EOF
    
    aws s3 cp $TEMP_DIR/sample_analysis.json s3://$S3_BUCKET_RESULTS/latest_analysis.json
    echo "✅ Sample data uploaded for testing"
fi

# Cleanup
rm -rf $TEMP_DIR
echo "🧹 Cleanup complete"