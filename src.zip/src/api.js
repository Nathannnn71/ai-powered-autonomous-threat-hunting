// API Configuration for Live Lambda Backend
const API_BASE_URL = 'https://rvwk89e37a.execute-api.us-east-1.amazonaws.com/prod';

// Fetch real threat data from Lambda/S3
export async function fetchThreatData() {
  try {
    const response = await fetch(`${API_BASE_URL}/data`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    console.log('✅ Live threat data received:', data);
    return data;
  } catch (error) {
    console.error('❌ Error fetching threat data:', error);
    return null;
  }
}

// Health check for API
export async function checkAPIHealth() {
  try {
    const response = await fetch(`${API_BASE_URL}/health`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const health = await response.json();
    console.log('✅ API Health:', health);
    return health;
  } catch (error) {
    console.error('❌ API Health check failed:', error);
    return null;
  }
}

// Mock logs fetcher (keeping for compatibility)
export async function fetchInitialLogs() {
  const threatData = await fetchThreatData();
  if (threatData && threatData.logs) {
    return threatData.logs.map((log, index) => ({
      id: 100 + index,
      source: log.src_ip || "Wazuh",
      msg: log.investigation_log || log.hypothesis,
      time: new Date().toLocaleString(),
      category: log.category,
      confidence: log.confidence
    }));
  }
  
  // Fallback to mock data
  return [
    {
      id: 101,
      source: "Auth Service",
      msg: "User root closed a login session.",
      time: "2025-09-20 10:01"
    },
    {
      id: 102,
      source: "File Server", 
      msg: "Large file transfer detected.",
      time: "2025-09-20 09:32"
    }
  ];
}
// Mock notifications fetcher
export async function fetchNotifications() {
  return [
    {
      id: 1,
      text: "System scan completed successfully."
    },
    {
      id: 2,
      text: "New alert: Unusual file activity detected."
    },
    {
      id: 3,
      text: "Threat intelligence updated."
    }
  ];
}
// api.js
export async function fetchInitialAlerts() {
  const threatData = await fetchThreatData();
  if (threatData && threatData.logs) {
    return threatData.logs.map((log, index) => ({
      id: index + 1,
      title: log.hypothesis || "Threat detected",
      severity: log.confidence > 0.8 ? "High" : log.confidence > 0.5 ? "Medium" : "Low",
      tactic: log.vulnerabilities?.[0] || "Unknown",
      confidence: Math.round((log.confidence || 0.5) * 100),
      narrative: log.investigation_log || log.hypothesis,
      time: new Date().toLocaleString(),
      source: log.src_ip || "Wazuh",
    }));
  }
  
  // Fallback to mock data
  return [
    {
      id: 1,
      title: "Suspicious login attempt",
      severity: "High",
      tactic: "Credential Access",
      confidence: 95,
      narrative: "Login from unusual location detected.",
      time: "2025-09-20 10:00",
      source: "Auth Service",
    },
    {
      id: 2,
      title: "Unusual file activity",
      severity: "Medium",
      tactic: "Exfiltration",
      confidence: 80,
      narrative: "Large file transfer outside working hours.",
      time: "2025-09-20 09:30",
      source: "File Server",
    },
  ];
}

export function subscribeToAlerts(callback) {
  // Simulate new alert every 10s
  const interval = setInterval(() => {
    callback({
      id: Date.now(),
      title: "New simulated alert",
      severity: ["High", "Medium", "Low"][Math.floor(Math.random() * 3)],
      tactic: "Execution",
      confidence: Math.floor(Math.random() * 100),
      narrative: "Random alert generated for testing.",
      time: new Date().toLocaleTimeString(),
      source: "Simulation",
    });
  }, 10000);

  return () => clearInterval(interval);
}

export async function acknowledgeAlert(id) {
  console.log("Acknowledged alert:", id);
}
// End of api.js
